import '../node_modules/admin-lte/plugins/jquery/jquery.min.js';
import '../node_modules/admin-lte/plugins/jquery-ui/jquery-ui.min.js';
$.widget.bridge('uibutton', $.ui.button)
import '../node_modules/admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js'
import './js/menu.js';

import './scss/style.scss';